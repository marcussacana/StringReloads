1 - Copy your script files to the "Scripts" Directory
2 - Launch the "PMan.exe" and install the plugin of your script format
4 - (Optional) Open the LstCleaner.ini and enable or disable the dialogue filter
3 - Run the "Run-Dump.bat" and wait
4 - Check the LST directory