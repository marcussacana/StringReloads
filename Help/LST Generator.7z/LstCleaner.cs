﻿using SacanaWrapper;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace LstCleaner {
    class Program {
        const string BreakLineFlag = "::BREAKLINE::";
        const string ReturnLineFlag = "::RETURNLINE::";
        static void Main(string[] args) {
            string ScriptDir = string.Empty;
            string LstDir = string.Empty;

            if (args.Length != 2 && args.Length != 3) {
                Console.WriteLine("Usage: ");
                Console.WriteLine("LstCleaner.exe \".\\Scripts\" \".\\Lst's\"");
                Console.WriteLine("LstCleaner.exe -d \".\\Scripts\" \".\\Lst's\" (Dump Only)");
                Console.WriteLine("LstCleaner.exe -i \".\\Scripts\" \".\\Lst's\" (Rewrite LST)");
                Console.WriteLine("LstCleaner.exe -p \".\\Scripts\" \".\\Lst's\" (Help Port a Strings.lst to Multiple's lst)");
                Console.WriteLine("LstCleaner.exe -c \".\\Scripts\" \".\\Lst's\" (Delete Empty Scripts and Lst's)");
                return;
            }
            if (args.Length == 2) {
                ScriptDir = args[0];
                LstDir = args[1];
            }

            bool WithSettings = File.Exists(AppDomain.CurrentDomain.BaseDirectory + "LstCleaner.ini");
            FilterSettings Settings = new FilterSettings();
            if (WithSettings) {
                AdvancedIni.FastOpen(out Settings, AppDomain.CurrentDomain.BaseDirectory + "LstCleaner.ini");
                Extensions.IgnoreList = Settings.IgnoreList.Unescape().Split('\n');
                Extensions.DenyList = Settings.DenyList.Unescape().Split('\n');
                Extensions.GameLineBreaker = Settings.BreakLine;
                Extensions.Sensitivity = Settings.Sensitivity;
                Extensions.AsianInput = Settings.AsianInput;
                Extensions.QuoteList = Settings.QuoteList.Unescape().Split('\n')
                .Where(x => x.Length == 2)
                .Select(x => {
                    return new Quote() { Start = x[0], End = x[1] };
                }).ToArray();
            }

            if (args.Length == 3) {
                if (args[0].ToLower().Trim(' ', '-', '/', '\\') == "d") {
                    ScriptDir = args[1];
                    LstDir = args[2];

                    if (!ScriptDir.EndsWith("\\"))
                        ScriptDir += "\\";

                    if (!LstDir.EndsWith("\\"))
                        LstDir += "\\";

                    if (!Directory.Exists(ScriptDir) || !Directory.Exists(LstDir)) {
                        Console.WriteLine("Directory Not Found...");
                        return;
                    }

                    string[] IgnoreList = WithSettings ? Settings.IgnoreList.Unescape().Split('\n') : new string[0];
                    Wrapper Dumper = new Wrapper();
                    string[] Scripts = Directory.GetFiles(ScriptDir, "*.*", SearchOption.AllDirectories);
                    foreach (string Script in Scripts) {
                        try {
                            string[] Lines = TrimStrings(Dumper.Import(Script, true, true), Settings.TrimList);
                            if (Lines.Length == 0)
                                throw new Exception("No Lines");

                            Console.WriteLine("Dumping {0}...", Path.GetFileName(Script));

                            string Output = LstDir + string.Format("Strings-{0}.lst", Path.GetFileNameWithoutExtension(Script));

                            int i = 0;
                            while (File.Exists(Output)) {
                                Output = LstDir + string.Format("Strings-{0}_{1}.lst", Path.GetFileNameWithoutExtension(Script), ++i);
                            }

                            List<string> dumped = new List<string>();
                            using (StreamWriter Writer = File.CreateText(Output)) {
                                foreach (string Line in Lines) {
                                    bool Dump = (Settings.Filter && Line.IsDialog()) || !Settings.Filter;

                                    if (!string.IsNullOrWhiteSpace(Settings.IgnoreList) && Dump && Settings.Filter)
                                        foreach (string Deny in IgnoreList)
                                            if (Line.Contains(Deny) || string.IsNullOrWhiteSpace(Line) || dumped.Contains(Line)) {
                                                Dump = false;
                                                break;
                                            }

                                    if (Dump) {
                                        dumped.Add(Line);
                                        Writer.WriteLine(Line.Replace("\n", BreakLineFlag).Replace("\r", ReturnLineFlag));
                                        Writer.WriteLine(Line.Replace("\n", BreakLineFlag).Replace("\r", ReturnLineFlag));
                                    }
                                }
                            }
                        } catch {
                            Console.WriteLine("Failed to Dump the {0}, Skiping...", Script);
                        }
                    }
                } else if (args[0].ToLower().Trim(' ', '-', '/', '\\') == "i") {
                    ScriptDir = args[1];
                    LstDir = args[2];

                    if (!ScriptDir.EndsWith("\\"))
                        ScriptDir += "\\";

                    if (!LstDir.EndsWith("\\"))
                        LstDir += "\\";

                    if (!Directory.Exists(ScriptDir) || !Directory.Exists(LstDir)) {
                        Console.WriteLine("Directory Not Found...");
                        return;
                    }


                    List<string> Raw = new List<string>();
                    string[] Lists = Directory.GetFiles(ScriptDir, "*.lst");

                    Dictionary<string, string> GlobalDatabase = new Dictionary<string, string>();
                    Console.WriteLine("Generating Global Database...");
                    foreach (string f in Lists) {
                        using (StreamReader Reader = File.OpenText(f)) {
                            while (Reader.Peek() != -1) {
                                try {
                                    string L1 = Reader.ReadLine().Replace(BreakLineFlag, "\n").Replace(ReturnLineFlag, "\r");
                                    if (string.IsNullOrEmpty(L1))
                                        continue;

                                    string L2 = Reader.ReadLine().Replace(BreakLineFlag, "\n").Replace(ReturnLineFlag, "\r");

                                    if (string.IsNullOrEmpty(L2) || L1 == L2)
                                        continue;

                                    string Ori = TrimAll(L1, Settings.TrimList);
                                    L1 = Minify(Ori);
                                    L2 = TrimAll(L2, Settings.TrimList);

                                    if (GlobalDatabase.ContainsKey(L1))
                                        continue;

                                    GlobalDatabase.Add(L1, L2);
                                    Raw.Add(Ori);
                                } catch (Exception ex) {
                                    continue;
                                }
                            }
                        }
                    }

                    List<string> Out = new List<string>();
                    string[] OutLists = Directory.GetFiles(LstDir, "*.lst");
                    Console.WriteLine($"Exporting Translation Database... {GlobalDatabase.Keys.LongCount()} Entries");
                    foreach (string f in OutLists) {
                        string[] Lines = File.ReadAllLines(f);
                        try {
                            for (int i = 0; i < Lines.Length - 1; i += 2) {
                                string Ori = Lines[i].Replace(BreakLineFlag, "\n").Replace(ReturnLineFlag, "\r");
                                string L1 = Minify(TrimAll(Ori, Settings.TrimList));

                                if (GlobalDatabase.ContainsKey(L1)) {
                                    Lines[i + 1] = GlobalDatabase[L1].Replace("\n", BreakLineFlag).Replace("\r", ReturnLineFlag);
                                    Out.Add(Ori);
                                }
                            }
                            File.WriteAllLines(f, Lines);
                        } catch (Exception ex) {
                            continue;
                        }
                    }

                    Console.WriteLine("Calculating Missmatches...");
                    string[] Missmatches = (from x in Raw where !Out.Contains(x) select x).ToArray();
                    if (Missmatches.LongLength > 0) {
                        Console.WriteLine($"Dumping Missmatches... ({Missmatches.LongLength} Found)");
                        using (StreamWriter Writer = new StreamWriter(LstDir + "Strings-Missmatches.lst")) {
                            foreach (string Missmatch in Missmatches) {
                                Writer.WriteLine(Missmatch.Replace(BreakLineFlag, "\n").Replace(ReturnLineFlag, "\r"));
                                Writer.WriteLine(Missmatch.Replace(BreakLineFlag, "\n").Replace(ReturnLineFlag, "\r"));
                            }
                            Writer.Flush();
                        }
                    }


                } else if (args[0].ToLower().Trim(' ', '-', '/', '\\') == "p") {
                    ScriptDir = args[1];
                    LstDir = args[2];

                    if (!ScriptDir.EndsWith("\\"))
                        ScriptDir += "\\";

                    if (!LstDir.EndsWith("\\"))
                        LstDir += "\\";


                    var ALST = Directory.GetFiles(LstDir, "*.lst");
                    Dictionary<string, string> RDB = new Dictionary<string, string>();
                    Dictionary<string, bool> MatchDB = new Dictionary<string, bool>();
                    Dictionary<string, string> SDB = new Dictionary<string, string>();

                    using (StreamReader Reader = File.OpenText(LstDir + "Strings.lst")) {
                        while (Reader.Peek() != -1) {
                            string L1 = TrimAll(Reader.ReadLine(), Settings.TrimList);
                            string L2 = TrimAll(Reader.ReadLine(), Settings.TrimList);

                            if (MatchDB.ContainsKey(L1))
                                continue;

                            RDB[Minify(L1)] = L2;
                            L1 = Minify(L1);
                            MatchDB.Add(L1, false);
                            SDB[L1] = L2;
                        }
                    }

                    foreach (string LST in ALST) {
                        if (LST.ToLower().EndsWith("strings.lst"))
                            continue;

                        using (StreamWriter Writer = File.CreateText(LST + ".new"))
                        using (StreamReader Reader = File.OpenText(LST)) {
                            while (Reader.Peek() != -1) {
                                string L1 = TrimAll(Reader.ReadLine(), Settings.TrimList);
                                string L2 = TrimAll(Reader.ReadLine(), Settings.TrimList);

                                Writer.WriteLine(L1);
                                L1 = Minify(L1);
                                if (MatchDB.ContainsKey(L1)) {
                                    MatchDB[L1] = true;
                                    L2 = SDB[L1];
                                }
                                Writer.WriteLine(L2);
                            }
                            Reader.Close();
                            Writer.Close();
                        }
                        File.Delete(LST);
                        File.Move(LST + ".new", LST);
                    }
                    string[] Keys = SDB.Keys.ToArray();
                    string[] Translations = SDB.Values.ToArray();
                    bool[] Found = MatchDB.Values.ToArray();
                    File.Delete(LstDir + "Strings.lst");
                    using (StreamWriter Writer = File.CreateText(LstDir + "Strings.lst")) {
                        for (uint i = 0; i < Keys.LongLength; i++) {
                            if (Found[i])
                                continue;
                            Writer.WriteLine(RDB[Keys[i]]);
                            Writer.WriteLine(Translations[i]);
                        }
                        Writer.Close();
                    }
                } else if (args[0].ToLower().Trim(' ', '-', '/', '\\') == "c") {
                    ScriptDir = args[1];
                    LstDir = args[2];
                    if (!ScriptDir.EndsWith("\\"))
                        ScriptDir += "\\";

                    if (!LstDir.EndsWith("\\"))
                        LstDir += "\\";

                    Console.WriteLine("Empty Cleaner Mode");
                    string[] LstList = Directory.GetFiles(LstDir);
                    string[] SrtList = Directory.GetFiles(ScriptDir);

                    uint Del = 0;
                    foreach (string Lst in LstList)
                        if (new FileInfo(Lst).Length == 0) {
                            File.Delete(Lst);
                            Del++;
                        }


                    foreach (string Srt in SrtList)
                        if (new Wrapper().Import(Srt).Length == 0) {
                            File.Delete(Srt);
                            Del++;
                        }

                    Console.WriteLine($"{Del} Files Deleted");
                } else {
                    Console.WriteLine("Bad Argument: {0}", args[0]);
                    return;
                }
                goto Finish;
            }

            if (!ScriptDir.EndsWith("\\"))
                ScriptDir += "\\";

            if (!LstDir.EndsWith("\\"))
                LstDir += "\\";

            if (!Directory.Exists(ScriptDir) || !Directory.Exists(LstDir)) {
                Console.WriteLine("Directory Not Found...");
                return;
            }

            string[] LSTs = Directory.GetFiles(LstDir, "*.lst");

            Console.WriteLine("Searching For Duplicates Entries...");
            foreach (string File in LSTs) {
                Dictionary<string, string> Data = new Dictionary<string, string>();
                uint Entries = 0;

                using (StreamReader Reader = System.IO.File.OpenText(File)) {
                    while (Reader.Peek() != -1) {
                        Entries++;
                        string L1 = TrimAll(Reader.ReadLine(), Settings.TrimList);
                        string L2 = TrimAll(Reader.ReadLine(), Settings.TrimList);

                        if (Data.ContainsKey(L1))
                            continue;
                        Data.Add(L1, L2);
                    }
                }

                System.IO.File.Delete(File);

                string[] KS = Data.Keys.ToArray();
                string[] VL = Data.Values.ToArray();

                using (StreamWriter Writer = System.IO.File.CreateText(File)) {
                    for (int i = 0; i < Data.Count; i++) {
                        Writer.WriteLine(KS[i]);
                        Writer.WriteLine(VL[i]);
                    }
                }

                if (Entries != Data.Count())
                    Console.WriteLine("\"{0}\" Optimized from {1} to {2} Entries", File, Entries, Data.Count());
            }

            LSTs = Directory.GetFiles(LstDir, "*.lst");

            Console.WriteLine("Searching for Duplicate Files...");
            foreach (string f1 in LSTs) {
                foreach (string f2 in LSTs) {
                    if (f1 == f2)
                        continue;

                    if (!File.Exists(f1) || !File.Exists(f2))
                        continue;

                    bool Diff = false;
                    using (StreamReader R1 = File.OpenText(f1)) {
                        using (StreamReader R2 = File.OpenText(f2)) {
                            while (R1.Peek() != -1 && R2.Peek() != -1) {
                                string L1 = TrimAll(R1.ReadLine(), Settings.TrimList);
                                string L2 = TrimAll(R2.ReadLine(), Settings.TrimList);
                                if (L1 != L2) {
                                    Diff = true;
                                    break;
                                }
                            }
                            if (R1.Peek() != R2.Peek())
                                Diff = true;
                        }
                    }

                    if (!Diff) {
                        Console.WriteLine("{0} is the same file of the {1}, Deleting...", Path.GetFileName(f1), Path.GetFileName(f2));
                        File.Delete(f2);
                    }
                }
            }

            LSTs = Directory.GetFiles(LstDir, "*.lst");

            Dictionary<string, string> Database = new Dictionary<string, string>();
            Console.WriteLine("Generating Fully Database...");
            foreach (string f in LSTs) {
                using (StreamReader Reader = File.OpenText(f)) {
                    while (Reader.Peek() != -1) {
                        string L1 = TrimAll(Reader.ReadLine(), Settings.TrimList);
                        string L2 = TrimAll(Reader.ReadLine(), Settings.TrimList);

                        if (Database.ContainsKey(L1))
                            continue;

                        Database.Add(L1, L2);
                    }
                }
            }

            Console.WriteLine("Extracting Missed Content...");
            uint Missed = 0;
            foreach (string s in Directory.GetFiles(ScriptDir, "*.*", SearchOption.AllDirectories)) {
                string MissFile = $"{LstDir}Strings-Miss{Missed}.lst";
                if (File.Exists(MissFile))
                    File.Delete(MissFile);
                Wrapper Reader = new Wrapper();
                string[] Strings = TrimStrings(Reader.Import(s, true, true), Settings.TrimList);

                string[] Untranslated = (from x in Strings where !Database.ContainsKey(x) select x).ToArray();

                if (Untranslated.Length != 0) {
                    Console.WriteLine("{0:D8} Missed Content Found At \"{1}\" Exporting...", Untranslated.Length, Path.GetFileName(s));
                    Missed++;
                    using (StreamWriter Writer = File.CreateText(MissFile)) {
                        foreach (string Line in Untranslated) {
                            bool Dump = (Settings.Filter && Line.IsDialog()) || !Settings.Filter;

                            if (!string.IsNullOrWhiteSpace(Settings.IgnoreList))
                                foreach (string Deny in Settings.IgnoreList.Split(','))
                                    if (Line.Contains(Deny)) {
                                        Dump = false;
                                        break;
                                    }

                            if (Dump) {
                                Writer.WriteLine(Line.Replace("\n", BreakLineFlag).Replace("\r", ReturnLineFlag));
                                Writer.WriteLine(Line.Replace("\n", BreakLineFlag).Replace("\r", ReturnLineFlag));
                            }
                        }
                    }
                }
            }
            Finish:;
            Console.WriteLine("Cleared!");
            Console.WriteLine("Press a Key to Exit...");
            Console.ReadKey();
        }

        public static string Minify(string Str) {
            return Str.Replace(BreakLineFlag, " ").Replace(ReturnLineFlag, " ").Replace("\n", " ").Replace("\r", " ").Replace("  ", " ").Replace("_r", "").Trim();
        }
        public static string[] TrimStrings(string[] Strings, string TrimList) {
            for (int i = 0; i < Strings.Length; i++) {
                Strings[i] = TrimAll(Strings[i], TrimList);
            }

            return Strings;
        }

        public static string TrimAll(string Str, string TrimList) {
            if (string.IsNullOrWhiteSpace(TrimList))
                return Str;

            string[] Trims = TrimList.Unescape().Split('\n');
            string Bak = string.Empty;
            while (Bak != Str) {
                Bak = Str;
                for (int x = 0; x < Trims.Length; x++)
                    Str = Trim(Str, Trims[x]);
            }

            return Str;
        }
        public static string Trim(string Str, string Trim) {
            if (Str.StartsWith(Trim))
                Str = Str.Substring(Trim.Length, Str.Length - Trim.Length);
            if (Str.EndsWith(Trim))
                Str = Str.Substring(0, Str.Length - Trim.Length);
            return Str;
        }
        /*
        public static bool IsText(string String) {
            if (String.ToUpper() == String && !String.Trim().Contains(" ") && String.Contains("_"))
                return false;
            return true;
        }
        */
    }

    public static class Extensions {
        internal static string[] IgnoreList;
        internal static string[] DenyList;
        internal static string GameLineBreaker;
        internal static bool AsianInput;
        internal static int Sensitivity;
        internal static Quote[] QuoteList;

        internal static double PercentOf(this string String, int Value) {
            var Result = Value / (double)String.Length;
            return Result * 100;
        }

        public static bool IsDialog(this string String) {
            if (string.IsNullOrWhiteSpace(String))
                return false;

            string Str = String.Trim();
            try {
                foreach (string Ignore in IgnoreList)
                    if (!string.IsNullOrEmpty(Ignore))
                        Str = Str.Replace(Ignore, "");

            } catch { }
            foreach (string Deny in DenyList)
                    if (!string.IsNullOrEmpty(Deny) && Str.ToLower().Contains(Deny.ToLower())) {
                        return false;
                    }
            Str = Str.Replace(GameLineBreaker, "\n");
                

            string[] Words = Str.Split(' ');

            char[] PontuationJapList = new char[] { '。', '？', '！', '…', '、', '―' };
            char[] SpecialList = new char[] { '_', '=', '+', '#', ':', '$', '@' };
            char[] PontuationList = new char[] { '.', '?', '!', '…', ',' };
            int Spaces = Str.Where(x => x == ' ' || x == '\t').Count();
            int Pontuations = Str.Where(x => PontuationList.Contains(x)).Count();
            int WordCount = Words.Where(x => x.Length >= 2 && !string.IsNullOrWhiteSpace(x)).Count();
            int Specials = Str.Where(x => char.IsSymbol(x)).Count();
            Specials += Str.Where(x => char.IsPunctuation(x)).Count() - Pontuations;
            int SpecialsStranges = Str.Where(x => SpecialList.Contains(x)).Count();

            int Uppers = Str.Where(x => char.IsUpper(x)).Count();
            int Latim = Str.Where(x => x >= 'A' && x <= 'z').Count();
            int Numbers = Str.Where(x => x >= '0' && x <= '9').Count();
            int NumbersJap = Str.Where(x => x >= '０' && x <= '９').Count();
            int JapChars = Str.Where(x => (x >= '、' && x <= 'ヿ') || (x >= '｡' && x <= 'ﾝ')).Count();
            int Kanjis = Str.Where(x => x >= '一' && x <= '龯').Count();


            bool IsCaps = Str.ToUpper() == Str;
            bool IsJap = JapChars + Kanjis > Latim / 2;


            //More Points = Don't Looks a Dialogue
            //Less Points = Looks a Dialogue
            int Points = 0;

            if (Str.Length > 4) {
                string ext = Str.Substring(Str.Length - 4, 4);
                try {
                    if (Path.GetExtension(ext).Trim('.').Length == 3)
                        Points += 2;
                } catch { }
            }

            bool BeginQuote = false;
            Quote? LineQuotes = null;
            foreach (Quote Quote in QuoteList) {
                BeginQuote |= Str.StartsWith(Quote.Start.ToString());

                if (Str.StartsWith(Quote.Start.ToString()) && Str.EndsWith(Quote.End.ToString())) {
                    Points -= 3;
                    LineQuotes = Quote;
                    break;
                } else if (Str.StartsWith(Quote.Start.ToString()) || Str.EndsWith(Quote.End.ToString())) {
                    Points--;
                    LineQuotes = Quote;
                    break;
                }
            }
            try {
                char Last = (LineQuotes == null ? Str.Last() : Str.TrimEnd(LineQuotes.Value.End).Last());
                if (IsJap && PontuationJapList.Contains(Last))
                    Points -= 3;

                if (!IsJap && (PontuationList).Contains(Last))
                    Points -= 3;

            } catch { }
            try {
                char First = (LineQuotes == null ? Str.First() : Str.TrimEnd(LineQuotes.Value.Start).First());
                if (IsJap && PontuationJapList.Contains(First))
                    Points -= 3;

                if (!IsJap && (PontuationList).Contains(First))
                    Points -= 3;

            } catch { }

            if (!IsJap) {
                foreach (string Word in Words) {
                    int WNumbers = Word.Where(c => char.IsNumber(c)).Count();
                    int WLetters = Word.Where(c => char.IsLetter(c)).Count();
                    if (WLetters > 0 && WNumbers > 0) {
                        Points += 2;
                    }
                    if (Word.Trim(PontuationList).Where(c => PontuationList.Contains(c)).Count() != 0) {
                        Points += 2;
                    }
                }
            }

            if (!BeginQuote && !char.IsLetter(Str.First()))
                Points += 2;

            if (Specials > WordCount)
                Points++;

            if (Specials > Latim + JapChars)
                Points += 2;

            if (SpecialsStranges > 0)
                Points += 2;

            if (SpecialsStranges > 3)
                Points++;

            if ((Pontuations == 0) && (WordCount <= 2) && !IsJap)
                Points++;

            if (Uppers > Pontuations + 2 && !IsCaps)
                Points++;

            if (Spaces > WordCount * 2)
                Points++;

            if (IsJap && Spaces == 0)
                Points--;

            if (!IsJap && Spaces == 0)
                Points += 2;

            if (WordCount <= 2 && Numbers != 0)
                Points += (int)(Str.PercentOf(Numbers) / 10);

            if (Str.Length <= 3 && !IsJap)
                Points++;

            if (Numbers >= Str.Length)
                Points += 3;

            if (IsJap && Kanjis / 2 > JapChars)
                Points--;

            if (IsJap && JapChars > Kanjis)
                Points--;

            if (IsJap && Latim != 0)
                Points += (int)(Str.PercentOf(Latim) / 10) + 2;

            if (IsJap && NumbersJap != 0)
                Points += (int)(Str.PercentOf(NumbersJap) / 10) + 2;

            if (IsJap && Numbers != 0)
                Points += (int)(Str.PercentOf(Numbers) / 10) + 3;

            if (IsJap && Pontuations != 0)
                Points += (int)(Str.PercentOf(Pontuations) / 10) + 2;

            if (Str.Trim() == string.Empty)
                return false;

            if (Str.Trim().Trim(Str.Trim().First()) == string.Empty)
                Points += 2;

            if (IsJap != AsianInput)
                return false;

            bool Result = Points < Sensitivity;
            return Result;
        }
        public static string Unescape(this string String) {
            if (string.IsNullOrWhiteSpace(String))
                return String;

            string Result = string.Empty;
            bool Special = false;
            foreach (char c in String) {
                if (c == '\\' & !Special) {
                    Special = true;
                    continue;
                }
                if (Special) {
                    switch (c) {
                        case '\\':
                            Result += '\\';
                            break;
                        case 'N':
                        case 'n':
                            Result += '\n';
                            break;
                        case 'T':
                        case 't':
                            Result += '\t';
                            break;
                        case 'R':
                        case 'r':
                            Result += '\r';
                            break;
                        case '"':
                            Result += '"';
                            break;
                        default:
                            Result += "\\" + c;
                            break;
                    }
                    Special = false;
                } else
                    Result += c;
            }

            return Result;
        }

    }
    internal struct Quote {
        public char Start;
        public char End;
    }
    [FieldParmaters(Name = "Filter")]
    internal struct FilterSettings {
        [FieldParmaters(DefaultValue = "", Name = "DenyList")]
        public string DenyList;
        [FieldParmaters(DefaultValue = "", Name = "IgnoreList")]
        public string IgnoreList;
        [FieldParmaters(DefaultValue = "", Name = "QuoteList")]
        public string QuoteList;
        [FieldParmaters(DefaultValue = "", Name = "TrimList")]
        public string TrimList;
        [FieldParmaters(DefaultValue = "\n", Name = "BreakLine")]
        public string BreakLine;
        [FieldParmaters(DefaultValue = false, Name = "Filter")]
        public bool Filter;
        [FieldParmaters(DefaultValue = false, Name = "AsianInput")]
        public bool AsianInput;
        [FieldParmaters(DefaultValue = 2, Name = "Sensitivity")]
        public int Sensitivity;
    }
}
